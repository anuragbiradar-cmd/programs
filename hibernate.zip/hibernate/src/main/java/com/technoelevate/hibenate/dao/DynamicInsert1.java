package com.technoelevate.hibenate.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.technoelevate.java.hibernate.dto.Student;

public class DynamicInsert1 {
	public static void main(String[] args) {
		EntityManagerFactory factory = null;
		EntityManager manager = null;
		EntityTransaction transaction = null;
		try {
			factory = Persistence.createEntityManagerFactory("hibernate12");
			manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			transaction.begin();

			Student student = new Student();
			student.setId(19);
			student.setName("Akhils");
			manager.persist(student);

			transaction.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			if (factory != null) {
				factory.close();
			}

			if (manager != null) {
				manager.close();
			}
		}

	}

}
