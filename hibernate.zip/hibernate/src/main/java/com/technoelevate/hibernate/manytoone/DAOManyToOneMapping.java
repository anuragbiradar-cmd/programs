package com.technoelevate.hibernate.manytoone;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class DAOManyToOneMapping {

	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory=null;
		EntityManager entityManager=null;
		EntityTransaction entityTransaction=null;
	try {
		entityManagerFactory=Persistence.createEntityManagerFactory("hibernate");
		entityManager=entityManagerFactory.createEntityManager();
		entityTransaction=entityManager.getTransaction();
		
		entityTransaction.begin();
		
		Box box=new Box();
		box.setBox_name("cello");
		
		Pen pen=new Pen();
		pen.setBox(box);
		pen.setPen_name("Gripper");
		entityManager.persist(pen);

		Pen pen1 = new Pen();
		pen1.setBox(box);
		pen1.setPen_name("Jetter");
		entityManager.persist(pen1);

		Pen pen2 = new Pen();
		pen2.setBox(box);
		pen2.setPen_name("flair");
		entityManager.persist(pen2);

		Pen pen3 = new Pen();
		pen3.setBox(box);
		pen3.setPen_name("Butterflow");
		entityManager.persist(pen3);

		Pen pen4 = new Pen();
		pen4.setBox(box);
		pen4.setPen_name("Etc");
		entityManager.persist(pen4);
	} finally {
		// TODO: handle finally clause
	}
		
		
	}	
	}


