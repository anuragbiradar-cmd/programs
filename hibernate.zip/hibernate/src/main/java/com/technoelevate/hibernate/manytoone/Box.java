package com.technoelevate.hibernate.manytoone;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Box {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int box_id;
	private String box_name;
	public int getBox_id() {
		return box_id;
	}
	public void setBox_id(int box_id) {
		this.box_id = box_id;
	}
	public String getBox_name() {
		return box_name;
	}
	public void setBox_name(String box_name) {
		this.box_name = box_name;
	}
	@Override
	public String toString() {
		return "Box [box_id=" + box_id + ", box_name=" + box_name + "]";
	}

}
