package com.technoelevate.hibernate.manytoone;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table
public class Pen {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int pen_id;
	private String pen_name;
	@ManyToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(referencedColumnName = "box_id")
	private Box box;
	public int getPen_id() {
		return pen_id;
	}
	public void setPen_id(int pen_id) {
		this.pen_id = pen_id;
	}
	public String getPen_name() {
		return pen_name;
	}
	public void setPen_name(String pen_name) {
		this.pen_name = pen_name;
	}
	public Box getBox() {
		return box;
	}
	public void setBox(Box box) {
		this.box = box;
	}
	@Override
	public String toString() {
		return "Pen [pen_id=" + pen_id + ", pen_name=" + pen_name + ", box=" + box + "]";
	}


}
