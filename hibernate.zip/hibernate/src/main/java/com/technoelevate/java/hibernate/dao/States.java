package com.technoelevate.java.hibernate.dao;

public class States {

}
