package com.technoelevate.java.hibernateDao2;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.technoelevate.java.hibernate.dto.Student;

public class StudentDao2 {

	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory = null;
		EntityManager entityManager = null;
		EntityTransaction entityTransaction = null;
		try {
			entityManagerFactory = Persistence.createEntityManagerFactory("hibernate");
			entityManager = entityManagerFactory.createEntityManager();
			entityTransaction = entityManager.getTransaction();
			entityTransaction.begin();
			Student student = new Student();

			String jpql = "From student";
			Query createQuery = entityManager.createQuery(jpql);
			createQuery.getResultList();
			List resultList = createQuery.getResultList();

			for (Object object : resultList) {
				System.out.println(object);

			}
//			Query createQuery1=entityManager.createQuery("Select Name from Student");
//			List resultList=createQuery1.getResultList();
//			for (Object object : resultList) {
//				System.out.println(object);
//			}
			entityTransaction.commit();
	
		entityManager.createQuery("update Student set Name='Akhil' where Id=3");
		int update = createQuery.executeUpdate();
		System.out.println(update+"rows affected");
		entityTransaction.commit();
		
		} catch (Exception e) {

		} finally {
			/*
			 * if (entityManagerFactory != null) { entityManagerFactory.close();
			 * 
			 * } if (entityManager != null) { entityManager.close();
			 * 
			 * } if (entityTransaction != null) { entityTransaction.rollback(); }
			 */
		}

	}

}
