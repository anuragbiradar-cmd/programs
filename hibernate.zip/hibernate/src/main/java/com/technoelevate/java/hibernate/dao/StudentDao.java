package com.technoelevate.java.hibernate.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.technoelevate.java.hibernate.dto.Student;

public class StudentDao {

	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory = null;
		EntityManager entityManager = null;
		EntityTransaction transaction = null;

		try {
			// JPA Logic
			entityManagerFactory = Persistence.createEntityManagerFactory("hibernate");
			entityManager = entityManagerFactory.createEntityManager();
			transaction = entityManager.getTransaction();
			transaction.begin();

//			Student student = new Student();
//			student.setId(2);
//			student.setName("megha");
//
//			entityManager.persist(student);

			// transaction.commit();

//			Student find=entityManager.find(Student.class, 1);
//			System.out.println(find);

//			Student find = entityManager.find(Student.class, 2);
//			find.setName("Suraj");
			
			Student find=entityManager.find(Student.class,1);
			entityManager.remove(find);
			transaction.commit();
			

		} catch (Exception e) {
			e.printStackTrace();

		}finally {
			if(entityManagerFactory!=null) {
				entityManagerFactory.close();
			}
			if(entityManager!=null) {
				entityManager.close();
			}
			if(transaction!=null) {
				transaction.rollback();
			}
		}
	}

	public void setId(int i) {
		// TODO Auto-generated method stub
		
	}

	public void setName(String string) {
		// TODO Auto-generated method stub
		
	}

}
