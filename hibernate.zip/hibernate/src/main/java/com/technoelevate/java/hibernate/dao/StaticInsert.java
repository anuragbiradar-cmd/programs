package com.technoelevate.java.hibernate.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class StaticInsert {
	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory = null;
		EntityManager entityManager = null;
		EntityTransaction transaction = null;
	
		try {
			
			entityManagerFactory = Persistence.createEntityManagerFactory("hibernate");
			entityManager = entityManagerFactory.createEntityManager();
			transaction = entityManager.getTransaction();
			transaction.begin();
			
			
			
			
			StudentDao student = new StudentDao();
			student.setId(11);
			student.setName("Yogesh");
			
			entityManager.persist(student);			
			
			transaction.commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			
			if(entityManagerFactory != null) {
				entityManagerFactory.close();
			}
			
			if(entityManager  != null) {
				entityManager .close();
			}
		}

	}

}
