package com.technoelevate.java.hibernate.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.mysql.cj.Query;

public class DynamicDelete {

	public static void main(String[] args) {
		EntityManagerFactory factory = null;
		EntityManager manager = null;
		EntityTransaction transaction = null;
		
		try {
			factory = Persistence.createEntityManagerFactory("student");
			manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			transaction.begin();
			
			String sql="delete from Student where name=:name";
			
			Query createQuery = (Query) manager.createQuery(sql);
			((javax.persistence.Query) createQuery).setParameter("name", "Sachin");
			int executeUpdate = ((javax.persistence.Query) createQuery).executeUpdate();
			
			if(executeUpdate!=0) {
				System.out.println(executeUpdate+"Row Affected");
			}
			
			
			
			transaction.commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			
			if(factory != null) {
				factory.close();
			}
			
			if(manager != null) {
				manager.close();
			}
		}

	}

}
