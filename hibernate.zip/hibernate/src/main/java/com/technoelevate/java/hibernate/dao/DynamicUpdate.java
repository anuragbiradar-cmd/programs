package com.technoelevate.java.hibernate.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class DynamicUpdate {

	public static void main(String[] args) {
		EntityManagerFactory factory = null;
		EntityManager manager = null;
		EntityTransaction transaction = null;
		
		try {
			factory = Persistence.createEntityManagerFactory("student");
			manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			transaction.begin();
			
			String sql="update Student set name=:name where id =:id";
			javax.persistence.Query query= manager.createQuery(sql);
			query.setParameter("id", Integer.parseInt(args[0]));
			query.setParameter("name", args[1]);
			int executeUpdate = query.executeUpdate();
			System.out.println(executeUpdate+"Row affected"); 
			
			
			
			transaction.commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			
			if(factory != null) {
				factory.close();
			}
			
			if(manager != null) {
				manager.close();
			}
		}
	}

}
