package com.technoelevate.java.hibernate.dao;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class DynamicRead {

	public static void main(String[] args) {
		EntityManagerFactory factory = null;
		EntityManager manager = null;
		EntityTransaction transaction = null;
		
		try {
			factory = Persistence.createEntityManagerFactory("student");
			manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			transaction.begin();
			
			Scanner s = new Scanner(System.in);
			String sql="from student where id =:id";
			javax.persistence.Query query= manager.createQuery(sql);
			query.setParameter("id", s.nextInt());
			Object singleResult = query.getSingleResult();
			
			System.out.println(singleResult);
			
			
			
			transaction.commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			
			if(factory != null) {
				factory.close();
			}
			
			if(manager != null) {
				manager.close();
			}
		}



	}


	}


