package com.technoelevate.java.hibernate.dto;

import java.io.Serializable;

import javax.persistence.*;
@Entity
@Table(name="Student_data1")
public class Student implements Serializable {
	@Id
	private int id;
	private String name;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		name = name;
	}
	@Override
	public String toString() {
		return "Student [Id=" + id + ", Name=" + name + "]";
	}
	

}
